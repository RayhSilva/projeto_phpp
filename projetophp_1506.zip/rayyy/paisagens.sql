-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 15-Jun-2023 às 16:47
-- Versão do servidor: 8.0.27
-- versão do PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `paisagens`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `paisagens`
--

DROP TABLE IF EXISTS `paisagens`;
CREATE TABLE IF NOT EXISTS `paisagens` (
  `id` int NOT NULL Auto_increment,
  `nome_turistico` varchar(100) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `estado` varchar(100) DEFAULT NULL,
  `pais` varchar(100) DEFAULT NULL,
  `tipo_paisagem` varchar(100) DEFAULT NULL,
  `clima` varchar(100) DEFAULT NULL,
  `bioma` varchar(100) DEFAULT NULL,
  `descricao` varchar(100) DEFAULT NULL,
  `natural_cultural` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Extraindo dados da tabela `paisagens`
--

INSERT INTO `paisagens` (`id`, `nome_turistico`, `cidade`, `estado`, `pais`, `tipo_paisagem`, `clima`, `bioma`, `descricao`, `natural_cultural`) VALUES
(1, 'Paisagem Idílica', 'Toquio', 'Shinjuku', 'Japão', 'Praia com arvore', 'Frio', 'Floresta Temperada', 'Lugar lindo', 'Natural'),
(2, 'Praia do Francês', 'Toquio', 'Shinjuku', 'Japão', 'Praia com arvore', 'Frio', 'Floresta Temperada', 'Lugar lindo', 'Natural'),
(3, 'Jericoacoara', 'Toquio', 'Shinjuku', 'Japão', 'Praia com arvore', 'Frio', 'Floresta Temperada', 'Lugar lindo', 'Natural'),
(4, 'Porto de Galinhas', 'Toquio', 'Shinjuku', 'Japão', 'Praia com arvore', 'Frio', 'Floresta Temperada', 'Lugar lindo', 'Natural'),
(5, 'Praia do Espelho', 'Toquio', 'Shinjuku', 'Japão', 'Praia com arvore', 'Frio', 'Floresta Temperada', 'Lugar lindo', 'Natural');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
