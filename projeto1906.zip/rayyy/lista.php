<!DOCTYPE html>
<html lang="en">
<head>
  <title>Site php</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>


<?php include("menu.php");?>


<div class="container-fluid p-5  text-white text-center" style="background-color:black">
  <h1>Lista de Paisagens pelo mundo..</h1>
  <p>Bando de Dados- Lista Responsiva</p> 
</div>
  
<div class="container-fluid mt-3">

  
  
 
 

  
  <div class="table-responsive">
    <table class="table table-bordered">
      <thead>
        <tr>
        
          <th>Nome Turistico</th>
          <th>Cidade</th>
          <th>Estado</th>
          <th>Páis</th>
          <th>Tipo de Paisagem</th>
          <th>Clima</th>
          <th>Bioma</th>
          <th>Descrição</th>
          <th>Natural ou Cultural</th>
         
        </tr>
      </thead>
      <tbody>
      

        <?php
          include("banco_dados_conexao.php");
          try {
            $sth = $dbh->prepare('SELECT * from paisagens');
            $sth->execute();
            $result = $sth->fetchAll(PDO::FETCH_ASSOC);
            if(!empty($result)) {
              foreach($result as $row) {
                echo "<tr>";
               
                echo "<td>". $row["nome_turistico"] ."</td>";
                echo "<td>". $row["cidade"] ."</td>";
                echo "<td>". $row["estado"] ."</td>";
                echo "<td>". $row["pais"] ."</td>";
                echo "<td>". $row["tipo_paisagem"] ."</td>";
                echo "<td>". $row["clima"] ."</td>";
                echo "<td>". $row["bioma"] ."</td>";
                echo "<td>". $row["descricao"] ."</td>";
                echo "<td>". $row["natural_cultural"] ."</td>";
            
                echo "</tr>";
              }
            } 
            $dbh = null;
          } catch (PDOException $e) {
            print "Error!: " . $e->getMessage();
            die();
          }
        ?>

      </tbody>
    </table>
  </div>




</div>


</body></html>