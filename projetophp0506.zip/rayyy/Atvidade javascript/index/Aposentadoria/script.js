function aposentadoria(){

    let idade = document.getElementById('idade').value;
    idade = parseInt(idade);

    let contribuicao = document.getElementById('contribuicao').value;
    contribuicao = parseInt(contribuicao);

    let masculino = document.getElementById('masc').checked;
    let feminino = document.getElementById('fem').checked;

    if (
        (masculino && idade >=62 && contribuicao>=35)
        ||
        (feminino && idade >=57 && contribuicao>=30)
    ) {
     document.getElementById('demo').innerHTML = "Pode Aposentar!!!!";
    } else {

        document.getElementById('demo').innerHTML = "Não Pode Aposentar!!!!";
    }





   
}