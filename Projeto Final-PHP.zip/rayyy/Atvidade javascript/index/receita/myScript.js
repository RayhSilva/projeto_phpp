function multiplicar(){

    let n1 = document.getElementById('num1').value;
    n1 = parseInt(n1);


    let Ovo = n1 *3;
    let Acucar = n1 *2;
    let Fuba = n1 *2;
    let Trigo = n1 *3;
    let Oleo = n1 *0.5;
    let Leite = n1 *1;
    let Fermento = n1 *1;

     let html= "";
    html = html + Ovo + " Ovos <br>";
    html = html + Acucar + " Xicaras (chá) de açucar <br>";
    html = html + Fuba + " Xicaras (chá) de Fuba <br>";
    html = html + Trigo + " Colheres (sopa) de farinha de trigo  <br>";
    html = html + Oleo + " Copo (americano) de oleo <br>";
    html = html + Leite + " Copo (americano) de leite <br>";
    html = html + Fermento + " Colher(sopa) de fermento em pó <br>";
    





    document.getElementById('demo').innerHTML = html;
}