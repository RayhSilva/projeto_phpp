<!DOCTYPE html>
<html lang="en">
<head>
<title>Sistemas Web Responsivos</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    
<?php include("menu.php"); ?>

<div class="container-fluid p-5  text-white text-center" style="background-color:black">
  <h1>Detalhes das Paisagens</h1>
  <p>Abaixo os detalhes gerais das paisagens</p> 
</div>
  
  
<div class="container-fluid mt-3">
  <h1>Detalhes do item</h1>
  <p>Abaixo os detalhes de um item da lista.</p> 

  <?php
    $id = $_GET['id'];
  ?>

<ul class="list-group">


  <?php
    include("banco_dados_conexao.php");
    try {
      $sth = $dbh->prepare("SELECT * FROM paisagens WHERE id = ?");
      $sth->bindParam( 1, $id );
      $sth->execute();
      $result = $sth->fetchAll(PDO::FETCH_ASSOC);
      if(!empty($result)) {
        echo " <li class='list-group-item'><b> ID: </b>". $result[0]['id']."</li>";
        echo " <li class='list-group-item'><b> Nome Turistico: </b>". $result[0]['nome_turistico'];
        echo " <li class='list-group-item'><b> Cidade: </b>". $result[0]['cidade'];
        echo " <li class='list-group-item'><b> Estado: </b>". $result[0]['estado'];
        echo " <li class='list-group-item'><b> País: </b>". $result[0]['pais'];
        echo " <li class='list-group-item'><b> Tipo de Paisagem: </b>". $result[0]['tipo_paisagem'];
        echo " <li class='list-group-item'><b> Clima: </b>". $result[0]['clima'];
        echo " <li class='list-group-item'><b> Bioma: </b>". $result[0]['bioma'];
        echo " <li class='list-group-item'><b> Descrição: </b>". $result[0]['descricao'];
        echo " <li class='list-group-item'><b> Natural ou Cultural: </b>". $result[0]['natural_cultural'];
       
       

      } 
      $dbh = null;
    } catch (PDOException $e) {
      print "Error!: " . $e->getMessage();
      die();
    }
  ?></ul>

<br><br>

<a href="excluirdetalhe.php?id=<?php echo $id; ?>" class="btn btn-dark">
    <img src="/rayyy/img/lixo.png" width="20" /> Excluir Item
</a>

<a href="edit_formulario.php?id=<?php echo $id; ?>" class="btn btn-dark text-white">
    <img src="/rayyy/img/editar.png" width="15" /> Editar
</a>


<br><br>

<a href="listaindex.php">Voltar</a>




</div>



<br><br>
</body>
</html>

